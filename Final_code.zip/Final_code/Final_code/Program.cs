﻿using OpenQA.Selenium.Firefox;
using OpenQA.Selenium;
using excel = Microsoft.Office.Interop.Excel;
using OpenQA.Selenium.Support;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using NUnit.Framework;

namespace Final_code
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                IWebDriver driver = new FirefoxDriver();   //Opening a new browser


                driver.Navigate().GoToUrl("https://www.ebiquity.com/en/contact-us/contact-form");      //Navigating to the contact us page
                driver.Manage().Window.Maximize();
                                
                IWebElement enquiries = driver.FindElement(By.LinkText("For press enquiries, please click here"));    //Testing the functionality of Enquiries button
                enquiries.Click();

                IWebElement clickhere = driver.FindElement(By.LinkText("click here"));
                bool status = clickhere.Displayed;

                driver.Navigate().Back();

                //Getting test data from excel file
                excel.Application exlAppl = new excel.Application();
                excel.Workbook workBook = exlAppl.Workbooks.Open(@"C:\Users\GUEST-01\Downloads\TestData");
                excel._Worksheet workSheet = workBook.Sheets[1];
                excel.Range range = workSheet.UsedRange;
                var count = range.Rows.Count;

                //Loop for multiple users, getting the elements' id and entering the data
                for (int i = (count-1); i <= count; i++)
                {
                    driver.FindElement(By.Id("email")).Clear();
                    driver.FindElement(By.Id("email")).SendKeys(range.Cells[1][i].value2);

                    driver.FindElement(By.Id("first_name")).Clear();
                    driver.FindElement(By.Id("first_name")).SendKeys(range.Cells[2][i].value2);

                    driver.FindElement(By.Id("last_name")).Clear();
                    driver.FindElement(By.Id("last_name")).SendKeys(range.Cells[3][i].value2);
                    driver.FindElement(By.Id("company")).Clear();
                    driver.FindElement(By.Id("company")).SendKeys(range.Cells[4][i].value2);
                    driver.FindElement(By.Id("title")).Clear();
                    driver.FindElement(By.Id("title")).SendKeys(range.Cells[5][i].value2);

                    var business = driver.FindElement(By.Id("00Nw0000008iSjL"));  //Dropdown
                    var selectBusiness = new SelectElement(business);
                    selectBusiness.SelectByText(range.Cells[6][i].value2);

                    var region = driver.FindElement(By.Id("00Nw0000008iSjO"));   //Dropdown
                    var selectElement = new SelectElement(region);
                    selectElement.SelectByText(range.Cells[8][i].value2);

                    driver.FindElement(By.Id("phone")).Clear();
                    driver.FindElement(By.Id("phone")).SendKeys((range.Cells[7][i].value2).ToString());

                    //Checking whether the Contact checkbox is checked or not
                    Boolean isChecked = driver.FindElement(By.Id("00Nw0000008iSjJ")).Selected; 
                    IWebElement contact = driver.FindElement(By.Id("00Nw0000008iSjJ"));
                    if (true == isChecked)
                    {
                        contact.Click();
                        Thread.Sleep(2000);
                        contact.Click();
                    }
                    else
                    {contact.Click();}

                    //Secret-key for bypassing captcha
                    String secretKey = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe";

                    // set g-response-code in page source (with javascript)
                    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                    js.ExecuteScript("document.getElementById('g-recaptcha-response').innerHTML = '" + secretKey + "';");
                   
                    Thread.Sleep(2000);

                    driver.FindElement(By.Id("contactSubmit")).Click(); //Submitting the contact form
                    
                    Assert.AreEqual(driver.Title, "Thank you for sending us your enquiry"); //Validating succesful submission
                    Thread.Sleep(5000);
                    if (i < count)                   //Checking whether we have reached the end of test data in Excel file
                    {
                      driver.Navigate().Back();
                    }


                }
                workBook.Close(true);
                exlAppl.Quit();
                driver.Close();    //Closing the browser

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }
    }
}


﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System;
using TechTalk.SpecFlow;

namespace BDD_ContactsUsPage
{
    [Binding]
    public class ContactUsPageSteps
    {
        public IWebDriver driver = null;

        [Given(@"open a browser and navigate to contact us page")]
        public void GivenOpenABrowserAndNavigateToContactUsPage()
        {
            if (driver == null)
            {
                driver = new FirefoxDriver();
            }

            driver.Navigate().GoToUrl("https://www.ebiquity.com/en/contact-us/contact-form");
            driver.Manage().Window.Maximize();
        }
        
        [When(@"enter all the user details")]
        public void GivenEnterAllTheUserDetails(Table table)
        {
            
            driver.FindElement(By.Id("email")).SendKeys(table.Rows[0]["Email"]);
            
            driver.FindElement(By.Id("first_name")).SendKeys(table.Rows[0]["First Name"]);
           
            driver.FindElement(By.Id("last_name")).SendKeys(table.Rows[0]["LastName"]);
           
            driver.FindElement(By.Id("company")).SendKeys(table.Rows[0]["Country"]);
            
            driver.FindElement(By.Id("title")).SendKeys(table.Rows[0]["Position"]);

            var selectBusiness = new SelectElement(driver.FindElement(By.Id("00Nw0000008iSjL")));
            selectBusiness.SelectByText(table.Rows[0]["Business Area"]);

            var region = driver.FindElement(By.Id("00Nw0000008iSjO"));
            var selectElement = new SelectElement(region);
            selectElement.SelectByText(table.Rows[0]["Your Region"]);

            
            driver.FindElement(By.Id("phone")).SendKeys(table.Rows[0]["Phone"].ToString());
            IWebElement contact = driver.FindElement(By.Id("00Nw0000008iSjJ"));
            contact.Click();
        }
        
        [When(@"captcha is bypassed")]
        public void WhenCaptchaIsBypassed()
        {
            String SiteKey = driver.FindElement(By.XPath(".//div[@class=\"g-recaptcha\"]")).GetAttribute("data-sitekey");
            String ActualKey = "6Lf66SwUAAAAAHcZEZcnp9TzKERoH1bqWvNAjghd";
            Assert.AreEqual(ActualKey, SiteKey);

            String secretKey = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe";
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("document.getElementById('g-recaptcha-response').innerHTML = '" + secretKey + "';");
        }
        
        [Then(@"submit and validating successfull submission")]
        public void ThenSubmitAndValidatingSuccessfullSubmission()
        {
            driver.FindElement(By.Id("contactSubmit")).Click();

            Assert.AreEqual(driver.Title, "Thank you for sending us your enquiry");
        }
        
        [Then(@"navigate back to contact us page")]
        public void ThenNavigateBackToContactUsPage()
        {
            driver.Navigate().GoToUrl("https://www.ebiquity.com/en/contact-us/contact-form");
            driver.Manage().Window.Maximize();
        }

        [Then(@"close the browser")]
        public void ThenCloseTheBrowser()
        {
            driver.Close();
        }

    }
}
